﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace AppMsg
{
    public class Cliente
    {
        private string _host;
        private int _port;

        public Cliente(string host, int port)
        {
            _host = host;
            _port = port;
        }
        public async Task EnviarMensajeAsync(string mensaje)
        {
            try
            {
                using (TcpClient client = new TcpClient())
                {
                    await client.ConnectAsync(_host, _port);
                    using (NetworkStream stream = client.GetStream())
                    {
                        byte[] buffer = Encoding.ASCII.GetBytes(mensaje);
                        await stream.WriteAsync(buffer, 0, buffer.Length);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al enviar mensaje: {ex.Message}");
            }
        }
    }
}
