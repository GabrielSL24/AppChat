using System;
using System.Windows.Forms;

namespace AppMsg
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            int port = 0;
            if(args.Length > 0 && int.TryParse(args[0], out port))
            {
                Application.Run(new Form1(port));
            }
            else
            {
                Application.Run(new Form1());
            }
        }
    }
}