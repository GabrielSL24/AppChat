﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace MiProyecto
{
    public class Servidor
    {
        private int _port;
        private TcpListener _server;

        public event EventHandler<string> MensajeRecibido;

        public Servidor(int port)
        {
            _port = port;
        }

        public void Iniciar()
        {
            try
            {
                _server = new TcpListener(IPAddress.Any, _port);
                _server.Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
                _server.Start();
                EsperarConexiones();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
        private async void EsperarConexiones()
        {
            while(true)
            {
                TcpClient client = await _server.AcceptTcpClientAsync();
                _ = ManejarClienteAsync(client);
            }
        }
        private async Task ManejarClienteAsync(TcpClient client)
        {
            NetworkStream stream = client.GetStream();
            byte[] buffer = new byte[1024];
            int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
            string message = Encoding.ASCII.GetString(buffer, 0, bytesRead);

            OnMensajeRecibido(message);

            stream.Close();
            client.Close();
        }
        protected virtual void OnMensajeRecibido(string mensaje)
        {
            MensajeRecibido?.Invoke(this, mensaje);
        }
    }
}