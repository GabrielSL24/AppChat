﻿namespace AppMsg
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonStartServer = new Button();
            textBoxMessages = new TextBox();
            textBoxPort = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBoxMessage = new TextBox();
            label3 = new Label();
            buttonSendMessage = new Button();
            textBoxServerPort = new TextBox();
            label4 = new Label();
            SuspendLayout();
            // 
            // buttonStartServer
            // 
            buttonStartServer.Location = new Point(12, 137);
            buttonStartServer.Name = "buttonStartServer";
            buttonStartServer.Size = new Size(111, 52);
            buttonStartServer.TabIndex = 0;
            buttonStartServer.Text = "Iniciar Servidor";
            buttonStartServer.UseVisualStyleBackColor = true;
            buttonStartServer.Click += buttonStartServer_Click;
            // 
            // textBoxMessages
            // 
            textBoxMessages.BackColor = Color.White;
            textBoxMessages.Location = new Point(516, 53);
            textBoxMessages.Multiline = true;
            textBoxMessages.Name = "textBoxMessages";
            textBoxMessages.ReadOnly = true;
            textBoxMessages.ScrollBars = ScrollBars.Vertical;
            textBoxMessages.Size = new Size(284, 383);
            textBoxMessages.TabIndex = 1;
            // 
            // textBoxPort
            // 
            textBoxPort.Location = new Point(12, 92);
            textBoxPort.Name = "textBoxPort";
            textBoxPort.Size = new Size(111, 27);
            textBoxPort.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(180, 85);
            label1.Name = "label1";
            label1.Size = new Size(110, 20);
            label1.TabIndex = 3;
            label1.Text = "Puerto Destino:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(180, 33);
            label2.Name = "label2";
            label2.Size = new Size(130, 20);
            label2.TabIndex = 4;
            label2.Text = "Redactar Mensaje:";
            // 
            // textBoxMessage
            // 
            textBoxMessage.Location = new Point(180, 124);
            textBoxMessage.Multiline = true;
            textBoxMessage.Name = "textBoxMessage";
            textBoxMessage.Size = new Size(318, 243);
            textBoxMessage.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(516, 21);
            label3.Name = "label3";
            label3.Size = new Size(138, 20);
            label3.TabIndex = 6;
            label3.Text = "Mensajes Entrantes:";
            // 
            // buttonSendMessage
            // 
            buttonSendMessage.Location = new Point(180, 384);
            buttonSendMessage.Name = "buttonSendMessage";
            buttonSendMessage.Size = new Size(318, 52);
            buttonSendMessage.TabIndex = 7;
            buttonSendMessage.Text = "Enviar";
            buttonSendMessage.UseVisualStyleBackColor = true;
            buttonSendMessage.Click += buttonSendMessage_Click;
            // 
            // textBoxServerPort
            // 
            textBoxServerPort.Location = new Point(296, 82);
            textBoxServerPort.Name = "textBoxServerPort";
            textBoxServerPort.Size = new Size(202, 27);
            textBoxServerPort.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(12, 53);
            label4.Name = "label4";
            label4.Size = new Size(139, 20);
            label4.TabIndex = 9;
            label4.Text = "Puerto del Servidor:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(812, 481);
            Controls.Add(label4);
            Controls.Add(textBoxServerPort);
            Controls.Add(buttonSendMessage);
            Controls.Add(label3);
            Controls.Add(textBoxMessage);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxPort);
            Controls.Add(textBoxMessages);
            Controls.Add(buttonStartServer);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonStartServer;
        private TextBox textBoxMessages;
        private TextBox textBoxPort;
        private Label label1;
        private Label label2;
        private TextBox textBoxMessage;
        private Label label3;
        private Button buttonSendMessage;
        private TextBox textBoxServerPort;
        private Label label4;
    }
}
