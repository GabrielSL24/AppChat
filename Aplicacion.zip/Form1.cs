using MiProyecto;
using System;
using System.Windows.Forms;

namespace AppMsg
{
    public partial class Form1 : Form
    {
        private Servidor _servidor;
        private Cliente _cliente;
        public Form1(int port = 0)
        {
            InitializeComponent();
            if (port > 0)
            {
                textBoxPort.Text = port.ToString();
                buttonStartServer.PerformClick();
            }
        }
        private void buttonStartServer_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxPort.Text, out int port))
            {
                _servidor = new Servidor(port);
                _servidor.MensajeRecibido += Servidor_MensajeRecibido;
                _servidor.Iniciar();
                textBoxMessages.AppendText($"Servidor iniciado en el puerto {port}\n");
            }
            else
            {
                MessageBox.Show("Por favor, ingresa un puerto v�lido.");
            }
        }
        private void buttonSendMessage_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxServerPort.Text, out int serverPort))
            {
                string mensaje = textBoxMessage.Text;
                _cliente = new Cliente("127.0.0.1", serverPort);
                _cliente.EnviarMensajeAsync(mensaje);
                textBoxMessages.AppendText($"Mensaje enviado al puerto {serverPort}: {mensaje}\n");
            }
            else
            {
                MessageBox.Show("Por favor, ingresa un puerto del servidor v�lido");
            }
        }
        private void Servidor_MensajeRecibido(object sender, string mensaje)
        {
            Invoke((Action)(() =>
            {
                textBoxMessages.AppendText($"Mensaje recibido: {mensaje}\n");
            }));
        }
    }
}
